<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="BP-tile-6R" tilewidth="166" tileheight="166" tilecount="9" columns="3">
 <image source="../../Pictures/Zombicide Tiles/BP-tile-6R.jpg" width="500" height="500"/>
</tileset>
